﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RmsAuto.Store.Cms.Misc.Thumbnails
{
	public class ThumbnailInfo
	{
		public string ContentType;
		public string FilePath;
		public DateTime LastModifiedDate;
	}
}
