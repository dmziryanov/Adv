﻿namespace DAL
{
    public class ModelList
    {
        public KeyNameModel _Brands;
        
    }
}