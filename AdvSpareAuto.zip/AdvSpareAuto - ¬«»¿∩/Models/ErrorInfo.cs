﻿namespace BootStrap.Models
{
    public class ErrorInfo
    {
        public string message { get; set; }
    }
}